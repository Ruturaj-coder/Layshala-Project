import React, { useEffect, useState } from "react";
import axios from "axios";

function Dashboard() {
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const fetchUserData = async () => {
      const token = localStorage.getItem("token");

      if (!token) {
        // If there's no token, redirect to login page
        window.location.href = "/login";
        return;
      }

      try {
        const response = await axios.get(
          "http://localhost:5000/api/auth/user-data",
          {
            headers: { "x-auth-token": token },
          }
        );
        setUserData(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
        window.location.href = "/login"; // Redirect to login on error
      }
    };

    fetchUserData();
  }, []);

  return (
    <div className="dashboard">
      {userData ? (
        <div>
          <h1>Welcome, {userData.name}!</h1>
          <p>Email: {userData.email}</p>
          <p>Mobile: {userData.mobile}</p>
          <div>
            {userData.image ? (
              <img
                src={userData.image} // Use the Base64 image data directly from the backend
                alt="Profile"
                style={{ width: "150px", height: "150px", borderRadius: "50%" }}
              />
            ) : (
              <p>No profile image available</p>
            )}
          </div>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
}

export default Dashboard;
