import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    const navigate = useNavigate();

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        // Clear previous error message
        setErrorMessage('');

        try {
            // Make POST request to the backend for login
            const response = await axios.post('http://localhost:5000/api/auth/login', { email, password });
            
            // If login is successful, save the token in localStorage
            localStorage.setItem('token', response.data.token);
            
            // Redirect to a new page (e.g., Dashboard or Home)
            navigate('/dashboard'); // Change this as needed
            
        } catch (error) {
            // Handle errors (e.g., invalid login credentials)
            setErrorMessage(error.response?.data?.error || 'Login failed, try again.');
        }
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            {errorMessage && <div className="error-message">{errorMessage}</div>}
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Email:</label>
                    <input
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Password:</label>
                    <input
                        type="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Login</button>
            </form>
        </div>
    );
}

export default Login;
