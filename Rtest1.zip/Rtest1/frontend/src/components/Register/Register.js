import React, { useState } from 'react';
import axios from 'axios';
import './Register.css';

const Register = () => {
    const [formData, setFormData] = useState({
        venue: '',
        date: '',
        studentName: '',
        dob: '',
        age: '',
        school: '',
        grade: '',
        college: '',
        occupation: '',
        gender: '',
        maritalStatus: '',
        aadhaarNo: '',
        panNo: '',
        religion: '',
        caste: '',
        nationality: '',
        previousDanceEducation: '',
        guruName: '',
        examsAppeared: '',
        gharana: '',
        parentDetails: {
            fatherName: '',
            fatherOccupation: '',
            motherName: '',
            motherOccupation: '',
        },
        homeAddress: '',
        phonePrimary: '',
        phoneAlternate: '',
        email: '',
        emergencyContact: '',
        passportPhoto: '',
        image: '',
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (name.includes('parentDetails')) {
            const [parentKey, parentValue] = name.split('.');
            setFormData((prevState) => ({
                ...prevState,
                parentDetails: {
                    ...prevState.parentDetails,
                    [parentValue]: value,
                },
            }));
        } else {
            setFormData({ ...formData, [name]: value });
        }
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        const reader = new FileReader();

        reader.onloadend = () => {
            setFormData({ ...formData, image: reader.result });
        };

        if (file) {
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            // Automatically set the password as the email
            const dataToSend = { ...formData, password: formData.email };
            const response = await axios.post('http://localhost:5000/api/register', dataToSend);
            alert(response.data.message);
        } catch (error) {
            console.error(error);
            alert('Registration failed. Please try again.');
        }
    };

    return (
        <div className="register-container">
            <h2>Register</h2>
            <form onSubmit={handleSubmit}>
                {/* Name */}
                <div>
                    <label>Name:</label>
                    <input
                        type="text"
                        name="studentName"
                        value={formData.studentName}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Email */}
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Mobile */}
                <div>
                    <label>Mobile:</label>
                    <input
                        type="text"
                        name="phonePrimary"
                        value={formData.phonePrimary}
                        onChange={handleInputChange}
                        required
                    />
                </div>

                {/* Image Upload */}
                <div>
                    <label>Upload Image:</label>
                    <input type="file" onChange={handleImageChange} required />
                </div>

                {/* Additional Fields */}
                <div>
                    <label>Venue:</label>
                    <input
                        type="text"
                        name="venue"
                        value={formData.venue}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Date:</label>
                    <input
                        type="date"
                        name="date"
                        value={formData.date}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>DOB:</label>
                    <input
                        type="date"
                        name="dob"
                        value={formData.dob}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Age:</label>
                    <input
                        type="number"
                        name="age"
                        value={formData.age}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>School:</label>
                    <input
                        type="text"
                        name="school"
                        value={formData.school}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Grade:</label>
                    <input
                        type="text"
                        name="grade"
                        value={formData.grade}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>College:</label>
                    <input
                        type="text"
                        name="college"
                        value={formData.college}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Occupation:</label>
                    <input
                        type="text"
                        name="occupation"
                        value={formData.occupation}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Gender:</label>
                    <input
                        type="text"
                        name="gender"
                        value={formData.gender}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Marital Status:</label>
                    <input
                        type="text"
                        name="maritalStatus"
                        value={formData.maritalStatus}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Aadhaar No:</label>
                    <input
                        type="text"
                        name="aadhaarNo"
                        value={formData.aadhaarNo}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Pan No:</label>
                    <input
                        type="text"
                        name="panNo"
                        value={formData.panNo}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Religion:</label>
                    <input
                        type="text"
                        name="religion"
                        value={formData.religion}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Caste:</label>
                    <input
                        type="text"
                        name="caste"
                        value={formData.caste}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Nationality:</label>
                    <input
                        type="text"
                        name="nationality"
                        value={formData.nationality}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Previous Dance Education:</label>
                    <input
                        type="text"
                        name="previousDanceEducation"
                        value={formData.previousDanceEducation}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Guru Name:</label>
                    <input
                        type="text"
                        name="guruName"
                        value={formData.guruName}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Exams Appeared:</label>
                    <input
                        type="text"
                        name="examsAppeared"
                        value={formData.examsAppeared}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Gharana:</label>
                    <input
                        type="text"
                        name="gharana"
                        value={formData.gharana}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Father's Name:</label>
                    <input
                        type="text"
                        name="parentDetails.fatherName"
                        value={formData.parentDetails.fatherName}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Father's Occupation:</label>
                    <input
                        type="text"
                        name="parentDetails.fatherOccupation"
                        value={formData.parentDetails.fatherOccupation}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Mother's Name:</label>
                    <input
                        type="text"
                        name="parentDetails.motherName"
                        value={formData.parentDetails.motherName}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Mother's Occupation:</label>
                    <input
                        type="text"
                        name="parentDetails.motherOccupation"
                        value={formData.parentDetails.motherOccupation}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Home Address:</label>
                    <input
                        type="text"
                        name="homeAddress"
                        value={formData.homeAddress}
                        onChange={handleInputChange}
                    />
                </div>

                <div>
                    <label>Emergency Contact:</label>
                    <input
                        type="text"
                        name="emergencyContact"
                        value={formData.emergencyContact}
                        onChange={handleInputChange}
                    />
                </div>

                {/* Submit Button */}
                <button type="submit">Register</button>
            </form>
        </div>
    );
};

export default Register;
